package Tanks.commands;

public class CommandMovableEx extends CommandEx
{
    //.....
}
