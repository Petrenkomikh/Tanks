package Tanks.commands;

public class CommandEx extends Exception
{
    
}
