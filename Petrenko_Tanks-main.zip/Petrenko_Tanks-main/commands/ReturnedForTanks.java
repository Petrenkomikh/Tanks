package Tanks.commands;

public interface ReturnedForTanks
{
    void returnForTank();
}
