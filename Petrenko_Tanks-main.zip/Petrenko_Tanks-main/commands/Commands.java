package Tanks.commands;

public interface Commands
{
    //public void ex() throws CommandEx (или Commands) ???
    public void execute() throws CommandEx;
    
}
