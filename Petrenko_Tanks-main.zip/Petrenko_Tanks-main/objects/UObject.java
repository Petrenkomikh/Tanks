package Tanks.objects;

public interface UObject
{
    void set(String key, Object value);
    Object get(String key);
    //Object del();
}
